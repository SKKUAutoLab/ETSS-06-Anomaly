import copy
import sys, math, re
from collections import defaultdict


def precook(s, n=4, out=False):
    """Takes a string as input and returns an object that can be given to
    either cook_refs or cook_test. This is optional: cook_refs and cook_test
    can take string arguments as well."""
    words = s.split()
    counts = defaultdict(int)
    for k in range(1, n + 1):
        for i in range(len(words) - k + 1):
            ngram = tuple(words[i:i + k])
            counts[ngram] += 1
    return (len(words), counts)


def cook_refs(refs, eff=None, n=4):  ## lhuang: oracle will call with "average"
    '''Takes a list of reference sentences for a single segment
    and returns an object that encapsulates everything that BLEU
    needs to know about them.'''

    reflen = []
    maxcounts = {}
    for ref in refs:
        rl, counts = precook(ref, n)
        reflen.append(rl)
        for (ngram, count) in counts.items():
            maxcounts[ngram] = max(maxcounts.get(ngram, 0), count)

    # Calculate effective reference sentence length.
    if eff == "shortest":
        reflen = min(reflen)
    elif eff == "average":
        reflen = float(sum(reflen)) / len(reflen)

    ## lhuang: N.B.: leave reflen computaiton to the very end!!

    ## lhuang: N.B.: in case of "closest", keep a list of reflens!! (bad design)

    return (reflen, maxcounts)


def cook_test(test, xxx_todo_changeme, eff=None, n=4):
    '''Takes a test sentence and returns an object that
    encapsulates everything that BLEU needs to know about it.'''
    (reflen, refmaxcounts) = xxx_todo_changeme
    testlen, counts = precook(test, n, True)

    result = {}

    # Calculate effective reference sentence length.

    if eff == "closest":
        result["reflen"] = min((abs(l - testlen), l) for l in reflen)[1]
    else:  ## i.e., "average" or "shortest" or None
        result["reflen"] = reflen

    result["testlen"] = testlen

    result["guess"] = [max(0, testlen - k + 1) for k in range(1, n + 1)]

    result['correct'] = [0] * n
    for (ngram, count) in counts.items():
        result["correct"][len(ngram) - 1] += min(refmaxcounts.get(ngram, 0), count)

    return result


class BleuScorer(object):
    """Bleu scorer.
    """

    __slots__ = "n", "crefs", "ctest", "_score", "_ratio", "_testlen", "_reflen", "special_reflen"

    # special_reflen is used in oracle (proportional effective ref len for a node).

    def copy(self):
        ''' copy the refs.'''
        new = BleuScorer(n=self.n)
        new.ctest = copy.copy(self.ctest)
        new.crefs = copy.copy(self.crefs)
        new._score = None
        return new

    def __init__(self, test=None, refs=None, n=4, special_reflen=None):
        ''' singular instance '''

        self.n = n
        self.crefs = []
        self.ctest = []
        self.cook_append(test, refs)
        self.special_reflen = special_reflen

    def cook_append(self, test, refs):
        '''called by constructor and __iadd__ to avoid creating new instances.'''

        if refs is not None:
            self.crefs.append(cook_refs(refs))
            if test is not None:
                cooked_test = cook_test(test, self.crefs[-1])
                self.ctest.append(cooked_test)  ## N.B.: -1
            else:
                self.ctest.append(None)  # lens of crefs and ctest have to match

        self._score = None  ## need to recompute

    def ratio(self, option=None):
        self.compute_score(option=option)
        return self._ratio

    def score_ratio(self, option=None):
        '''return (bleu, len_ratio) pair'''
        return (self.fscore(option=option), self.ratio(option=option))

    def score_ratio_str(self, option=None):
        return "%.4f (%.2f)" % self.score_ratio(option)

    def reflen(self, option=None):
        self.compute_score(option=option)
        return self._reflen

    def testlen(self, option=None):
        self.compute_score(option=option)
        return self._testlen

    def retest(self, new_test):
        if type(new_test) is str:
            new_test = [new_test]
        assert len(new_test) == len(self.crefs), new_test
        self.ctest = []
        for t, rs in zip(new_test, self.crefs):
            self.ctest.append(cook_test(t, rs))
        self._score = None

        return self

    def rescore(self, new_test):
        ''' replace test(s) with new test(s), and returns the new score.'''

        return self.retest(new_test).compute_score()

    def size(self):
        assert len(self.crefs) == len(self.ctest), "refs/test mismatch! %d<>%d" % (len(self.crefs), len(self.ctest))
        return len(self.crefs)

    def __iadd__(self, other):
        '''add an instance (e.g., from another sentence).'''

        if type(other) is tuple:
            ## avoid creating new BleuScorer instances
            self.cook_append(other[0], other[1])
        else:
            assert self.compatible(other), "incompatible BLEUs."
            self.ctest.extend(other.ctest)
            self.crefs.extend(other.crefs)
            self._score = None  ## need to recompute

        return self

    def compatible(self, other):
        return isinstance(other, BleuScorer) and self.n == other.n

    def single_reflen(self, option="average"):
        return self._single_reflen(self.crefs[0][0], option)

    def _single_reflen(self, reflens, option=None, testlen=None):

        if option == "shortest":
            reflen = min(reflens)
        elif option == "average":
            reflen = float(sum(reflens)) / len(reflens)
        elif option == "closest":
            reflen = min((abs(l - testlen), l) for l in reflens)[1]
        else:
            assert False, "unsupported reflen option %s" % option

        return reflen

    def recompute_score(self, option=None, verbose=0):
        self._score = None
        return self.compute_score(option, verbose)

    def compute_score(self, option=None, verbose=0):
        # 基本参数设置
        n = self.n  # n-gram的最大阶数
        small = 1e-9  # 防止除零的小量（用于分子）
        tiny = 1e-15  # 更小的保护值（用于分母）
        bleu_list = [[] for _ in range(n)]  # 存储每个句子的各阶BLEU分数

        # 结果缓存检查
        if self._score is not None:
            return self._score

            # 设置默认参考长度计算策略
        if option is None:
            option = "average" if len(self.crefs) == 1 else "closest"

            # 初始化统计量
        self._testlen = 0  # 总候选文本长度
        self._reflen = 0  # 总参考文本有效长度
        totalcomps = {
            'testlen': 0,
            'reflen': 0,
            'guess': [0] * n,  # 各阶n-gram总数
            'correct': [0] * n  # 各阶匹配数
        }

        # 遍历每个句子计算统计量
        for comps in self.ctest:
            # 当前句子的候选长度
            testlen = comps['testlen']
            self._testlen += testlen  # 累加到总长度

            # 计算参考长度
            if self.special_reflen is None:
                # 常规计算（根据选项选择策略）
                reflen = self._single_reflen(comps['reflen'], option, testlen)
            else:
                # 使用预设的特殊参考长度
                reflen = self.special_reflen
            self._reflen += reflen

            # 累加各阶统计量
            for k in range(n):
                totalcomps['guess'][k] += comps['guess'][k]  # 候选n-gram总数
                totalcomps['correct'][k] += comps['correct'][k]  # 匹配数

            # 计算当前句子的各阶BLEU
            bleu = 1.0  # 初始值
            for k in range(n):
                # 计算k+1阶精度（带数值保护）
                bleu *= (float(comps['correct'][k]) + tiny) / (float(comps['guess'][k]) + small)
                # 计算几何平均并存入列表
                bleu_list[k].append(bleu ** (1. / (k + 1)))

                # 简短惩罚计算
            ratio = (testlen + tiny) / (reflen + small)
            if ratio < 1:
                # 应用指数惩罚
                for k in range(n):
                    bleu_list[k][-1] *= math.exp(1 - 1 / ratio)

                    # 调试输出
            if verbose > 1:
                print(comps, reflen)

                # 汇总全局统计量
        totalcomps['reflen'] = self._reflen
        totalcomps['testlen'] = self._testlen

        # 计算最终各阶BLEU
        bleus = []
        bleu = 1.0
        for k in range(n):
            # 累积各阶精度
            bleu *= (totalcomps['correct'][k] + tiny) / (totalcomps['guess'][k] + small)
            # 取几何平均
            bleus.append(bleu ** (1. / (k + 1)))

            # 应用全局简短惩罚
        ratio = (self._testlen + tiny) / (self._reflen + small)
        if ratio < 1:
            for k in range(n):
                bleus[k] *= math.exp(1 - 1 / ratio)

                # 调试输出
        # if verbose > 0:
        #     print(totalcomps)
        #     print("ratio:", ratio)

            # 缓存结果
        self._score = bleus
        return self._score, bleu_list

class Bleu:
    def __init__(self, n=4, sep2w=False):
        # default compute Blue score up to 4
        self._n = n
        self._hypo_for_image = {}
        self.ref_for_image = {}
        self.bleu_scorer = BleuScorer(n=self._n)
        self.sep2w = sep2w
        if sep2w:
            self.bleu_scorer_wt = BleuScorer(n=self._n)
            self.bleu_scorer_wy = BleuScorer(n=self._n)

    def append(self, gts, res, mode=None):
        if self.sep2w:
            if mode == 'what':
                self.bleu_scorer_wt += (res, gts)
            elif mode == 'why':
                self.bleu_scorer_wy += (res, gts)
            else:
                raise ValueError('unknown mode %s' % mode)
        else:
            self.bleu_scorer += (res, gts)

    def compute_score(self):
        # score, scores = bleu_scorer.compute_score(option='shortest')
        score, scores = self.bleu_scorer.compute_score(option='closest', verbose=1)
        # score, scores = bleu_scorer.compute_score(option='average', verbose=1)

        if not self.sep2w:
            # return (bleu, bleu_info)
            return score, scores
        else:
            score_wt, scores_wt = self.bleu_scorer_wt.compute_score(option='closest', verbose=1)
            score_wy, scores_wy = self.bleu_scorer_wy.compute_score(option='closest', verbose=1)
            return score, scores, score_wt, scores_wt, score_wy, scores_wy

    def method(self):
        return "Bleu"
from alchemy_cat.dl_config import Config, load_config, Config ,Param2Tune,IL

basecfg_path = './configs/base/basecfg.py'
datacfg_path = './configs/base/dota_movad_rgb_cfg.py'
modelcfg_path = './configs/model/poma/vst/instance_detection/vst_ins_fpn(0)_prompt(1)_rnn.py'

cfg = Config()
cfg.basecfg = load_config(basecfg_path)
cfg.datacfg = load_config(datacfg_path)
cfg.modelcfg = load_config(modelcfg_path)

cfg.unfreeze()
# update VCL
cfg.datacfg.train_dataset.cfg.VCL = 8
# prepare train dataset
cfg.datacfg.train_dataset.data = cfg.datacfg.train_dataset.cfg.type(**cfg.datacfg.train_dataset.cfg)
# prepare test dataset
cfg.datacfg.test_dataset.data = cfg.datacfg.test_dataset.cfg.type(**cfg.datacfg.test_dataset.cfg)

# update some data
# cfg.basecfg.basic.model_type = 'poma_prompt_no_fpn_rnn'
cfg.basecfg.basic.model_type = 'poma_ins,fpn(0),prompt(1)'
cfg.basecfg.basic.VCL = cfg.datacfg.train_dataset.cfg.VCL
cfg.basecfg.basic.NF = cfg.modelcfg.NF

cfg.basecfg.basic.proxy_tasks = cfg.modelcfg.proxy_task.task_names
if cfg.modelcfg.proxy_task.use_ins_anomaly:
    cfg.basecfg.basic.apply_ins_loss = True
    cfg.basecfg.basic.ins_loss_weight = 1

# update model-aware cfg
cfg.modelcfg.ins_encoder.pmt_decoder.twoway.depth = 4
cfg.modelcfg.ins_decoder.block_depth = 4

# cfg.basecfg.basic.directly_load = "/data/qh/DoTA/poma/reload,prompt,rnn,vcl=8,depth=4/checkpoints/model-160.pt"
# cfg.basecfg.basic.whole_load = True